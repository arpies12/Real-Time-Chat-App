// app.js
const socket = io();

const chatBox = document.getElementById('chat-box');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');

// Sending user message
sendBtn.addEventListener('click', () => {
  const message = messageInput.value.trim();
  if (message) {
    appendMessage('You', message, 'outgoing');
    socket.emit('message', message);
    messageInput.value = '';
  }
});

// Listening for messages from server
socket.on('message', (data) => {
  appendMessage(data.user, data.text, data.user === 'Bot' ? 'incoming' : 'outgoing');
});

// Append message to chat box
function appendMessage(user, message, type) {
  const msgDiv = document.createElement('div');
  msgDiv.classList.add('message', type);
  msgDiv.innerHTML = `<strong>${user}:</strong> ${message}`;
  chatBox.appendChild(msgDiv);
  chatBox.scrollTop = chatBox.scrollHeight;
}


// Simulate typing indicator before bot responds (app.js)
sendBtn.addEventListener('click', () => {
  const message = messageInput.value.trim();
  if (message) {
    appendMessage('You', message, 'outgoing');
    socket.emit('message', message);
    messageInput.value = '';

    // Show typing indicator
    appendMessage('Bot', 'Bot is typing...', 'incoming typing');
  }
});

socket.on('message', (data) => {
  const typingIndicator = document.querySelector('.typing');
  if (typingIndicator) typingIndicator.remove(); // Remove typing indicator

  appendMessage(data.user, data.text, data.user === 'Bot' ? 'incoming' : 'outgoing');
});
