const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Predefined bot responses and interactions
const botReplies = {
  hello: "Hi there! How's your day going?",
  bye: "Goodbye! Catch you later!",
  help: "I'm here to help. You can ask me about the time, weather, or even ask for a joke!",
  time: () => `The current time is ${new Date().toLocaleTimeString()}.`,
  date: () => `Today's date is ${new Date().toLocaleDateString()}.`,
  joke: "Why don't programmers like nature? It has too many bugs.",
  weather: "I'm not a weather expert, but it's always sunny in the cloud!",
  default: "Sorry, I don't quite understand. Try asking for help, or say 'tell me a joke'."
};

// Helper function to get bot response based on the message
function getBotResponse(message) {
  const lowerCaseMessage = message.toLowerCase();
  if (lowerCaseMessage.includes('hello')) return botReplies.hello;
  if (lowerCaseMessage.includes('bye')) return botReplies.bye;
  if (lowerCaseMessage.includes('help')) return botReplies.help;
  if (lowerCaseMessage.includes('time')) return botReplies.time();
  if (lowerCaseMessage.includes('date')) return botReplies.date();
  if (lowerCaseMessage.includes('joke')) return botReplies.joke;
  if (lowerCaseMessage.includes('weather')) return botReplies.weather;
  return botReplies.default;
}

app.use(express.static('public'));

io.on('connection', (socket) => {
  console.log('New user connected');

  // Listen for incoming messages from the user
  socket.on('message', (message) => {
    // Broadcast the user's message to everyone (except the sender)
    socket.broadcast.emit('message', { user: 'User', text: message });

    // Generate and send the bot's response only to the sender
    const botMessage = getBotResponse(message);

    setTimeout(() => {
      // Emit bot response ONLY to the sender
      socket.emit('message', { user: 'Bot', text: botMessage });
    }, 1000); // Delay for more realistic bot response
  });

  socket.on('disconnect', () => {
    console.log('User disconnected');
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
